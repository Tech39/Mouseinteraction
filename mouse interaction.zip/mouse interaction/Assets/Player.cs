﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {
	public int level=5;
	public int health=70;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		float movementX = Input.GetAxis("Mouse X");
		float movementY = Input.GetAxis("Mouse X");
        if(movementX!=0)
        {
			print(movementX)
        }
		if(movementY !=0)
        {
			print("moving in Y axis" + movementY);
        }




	}
}
